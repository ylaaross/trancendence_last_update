from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status, serializers
from django.contrib.auth.models import User
# Create your views here.
from rest_framework.response import Response
from rest_framework.decorators import api_view
from user_managemanet.models import Friendship,CustomUser
from django.db.models import Q
@api_view(['GET'])
def chathome(request):
    
    # print(f"USER ------------>  {request.user}")
    return Response("Welcome To chat 1337  page")



def get_non_friends(authenticated_user):
    friends = Friendship.objects.filter(
        Q(user=authenticated_user) | Q(friend=authenticated_user),
        accepted=True
    ).values_list('user', 'friend')  

    friend_ids = set(
        user_id for friend_pair in friends for user_id in friend_pair if user_id != authenticated_user.id
    )

    non_friends = CustomUser.objects.exclude(
        Q(pk=authenticated_user.pk) | Q(pk__in=friend_ids)
    )

    return non_friends


@api_view(['GET'])
def list_non_friends(request):
    
    if not request.user.is_authenticated:
        return Response({"error": "Authentication required"}, status=404)
        
    
    authenticated_user = request.user
    non_friends = get_non_friends(authenticated_user)
    
    # Serialize the data with details about invitations
    data = []
    for user in non_friends:
        has_invitation = Friendship.objects.filter(
            user=authenticated_user, friend=user, accepted=False
        ).exists()

        # Directly use avatar if it's already a URL or path
        avatar = user.avatar if user.avatar else None

        data.append({
            "id": user.id,
            "username": user.username,
            "avatar": avatar,
            "invitation_sent": has_invitation  # True if an invitation exists
        })
    
    return Response({"non_friends": data}, status=200)
# def index(request):
#     return render(request, "index.html")

# def room(request, room    _name):
#     return render(request, "room.html", {"room_name": room_name})


# class UserListView(APIView):
#     def get(self, request, *args, **kwargs):
#         # Fetch all users from the database
#         users = User.objects.all()

#         # Define the serializer inline
#         class UserSerializer(serializers.ModelSerializer):
#             class Meta:
#                 model = User
#                 fields = ['id', 'username', 'email', 'first_name', 'last_name', 'is_active', 'date_joined']
        
#         # Serialize the user data
#         serializer = UserSerializer(users, many=True)

#         # Get the ID and username of the authenticated user
#         authenticated_user_id = request.user.id if request.user.is_authenticated else None
#         authenticated_user_name = request.user.username if request.user.is_authenticated else None

#         # Return the serialized data along with the authenticated user's ID and name
#         response_data = {
#             'authenticated_user_id': authenticated_user_id,
#             'authenticated_user_name': authenticated_user_name,
#             'users': serializer.data
#         }

#         return Response(response_data, status=status.HTTP_200_OK)